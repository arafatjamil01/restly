<?php do_action( 'tp_footer' ); ?>
<?php wp_footer(); ?>
</body>
</html> 